import os
import base64

from time import sleep 

def _input(text):
            print(text, end='')
            inp = input()
            return inp

def crtime():
    return datetime.datetime.now(timezone('Europe/Moscow')).strftime('%H:%M:%S')

def slist(lst):
	return[stat for stat in lst if stat != '' and stat != ' ']

def check_token(token):
	check = requests.get(f'https://discord.com/api/{env["api"]}/auth/login',
						headers={'Authorization': token})
	try:
		return True if check.status_code == 200 else False
	except Exception:
		print('Не могу соеденится с discord.com')
		raise Exception()
				
def error_log(name, error):
	with open(name, 'r') as log:
		previous = log.read()

	with open(name, 'w') as log:
		log.write(str(previous) + "\n" + error)
		log.close()

def clear(): 
	if os.name == 'nt': 
		_ = os.system('cls') 
	else: 
		_ = os.system('clear') 