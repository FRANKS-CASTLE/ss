import sys
import numpy
import discord
import datetime
import traceback
from discord.ext import commands

class CommandErrorHandler(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        
    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if hasattr(ctx.command, 'on_error'):
            return

        cog = ctx.cog
        if cog:
            if cog._get_overridden_method(cog.cog_command_error) is not None:
                return

        ignored = (commands.CommandNotFound, )

        error = getattr(error, 'original', error)

        if isinstance(error, ignored):
            return

        if isinstance(error, commands.DisabledCommand):
            await ctx.send(f'{ctx.command} был отключен.')

        if isinstance(error, commands.CommandNotFound):
            embed = discord.Embed(title='ОШИБКА', description='Команда не найдена', timestamp=datetime.datetime.today())
            embed.set_footer(text='© i0x') 
            await ctx.send(embed=embed)

        elif isinstance(error, commands.CheckFailure):
            embed = discord.Embed(title='ОШИБКА', description='Вам не хватает разрешения на выполнение этой команды')
            embed.set_footer(text='© i0x') 
            await ctx.send(embed=embed)

        elif isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(title='ОШИБКА', description='Недопустимое изображение', timestamp=datetime.datetime.today())
            embed.set_footer(text='© i0x') 
            await ctx.send(embed=embed)

        elif isinstance(error, numpy.AxisError):
            embed = discord.Embed(title='ОШИБКА', description='Недопустимое изображение', timestamp=datetime.datetime.today())
            embed.set_footer(text='© i0x') 
            await ctx.send(embed=embed)

        elif isinstance(error, discord.errors.Forbidden):
            embed = discord.Embed(title='ОШИБКА', description='Ошибка Дискорда: ' + str(error), timestamp=datetime.datetime.today())
            embed.set_footer(text='© i0x') 
            await ctx.send(embed=embed)

        elif isinstance(error, commands.NoPrivateMessage):
            try:
                await ctx.author.send(f'{ctx.command} не может быть использован в ЛС.')
            except discord.HTTPException:
                pass

        elif 'Cannot send an empty message' in str(error):
            embed = discord.Embed(title='ОШИБКА', description='Не могу отправить пустое сообщение', timestamp=datetime.datetime.today())
            embed.set_footer(text='© i0x') 
            await ctx.send(embed=embed)

        else:
            embed = discord.Embed(title='ОШИБКА', description=str(error), timestamp=datetime.datetime.today())
            embed.set_footer(text='© i0x')
            await ctx.send(embed=embed)
            traceback.print_exception(type(error), error, error.__traceback__, file=sys.stderr)

    @commands.command(name="repeat", aliases=['mimic', 'copy'], description="-info:Повторить сообщение")
    async def do_repeat(self, ctx, *, inp: str):
        await ctx.send(inp)

    @do_repeat.error
    async def do_repeat_handler(self, ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            if error.param.name == 'inp':
                await ctx.send("Вы забыли ввести текст который надо повторить!")

def setup(bot):
    bot.add_cog(CommandErrorHandler(bot))