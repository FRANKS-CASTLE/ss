import discord

from disputils import BotConfirmation
from discord.ext import commands

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.has_permissions(kick_members=True)
    @commands.command(name="kick", description="-moderation:Кикнуть пользователя", no_pm=True)
    async def kick(self, ctx, user : discord.Member):
        """Kicks a user from the server."""
        if ctx.author == user:
            await ctx.send("Вы не можете кикнуть себя.")
        else:
            confirmation = BotConfirmation(ctx)
            await confirmation.confirm("Вы уверенны?")

            if confirmation.confirmed:
                await confirmation.update("Подтверждено", hide_author=True)
                await user.kick()
                embed = discord.Embed(title=f'Пользователь {user.name} был кикнут.')
                embed.add_field(name="До свидания!", value=":boot:")
                embed.set_thumbnail(url=user.avatar_url)
                await ctx.send(embed=embed)
            else:
                await confirmation.update("Отменено", hide_author=True)
    @commands.has_permissions(ban_members=True)
    @commands.command(name="ban", description="-moderation:Забанить пользователя", no_pm=True)
    async def ban(self, ctx, user : discord.User, *, reason : str):
        """Bans a user from the server."""
        if ctx.author == user:
            await ctx.send("Вы не можете забанить себя.")
        else:
            confirmation = BotConfirmation(ctx)
            await confirmation.confirm("Вы уверенны?")

            if confirmation.confirmed:
                await confirmation.update("Подтверждено", hide_author=True)
                await ctx.guild.ban(discord.Object(user.id), reason=reason)
                embed = discord.Embed(title=f'Пользователь {user.name} забанен. ')
                embed.add_field(name="До свидания!", value=":hammer:")
                embed.set_thumbnail(url=user.avatar_url)
                await ctx.send(embed=embed)
            else:
                await confirmation.update("Отменено", hide_author=True)

    @commands.has_permissions(ban_members=True)
    @commands.command(name="hackban", description="-moderation:Хак-Забанить пользователя", no_pm=True)
    async def hackban(self, ctx, user : discord.User, *, reason : str):
        """Bans a user from the server."""
        if ctx.author == user:
            await ctx.send("Вы не можете забанить себя.")
        else:
            try:
                int(user.id)
            except:
                return await ctx.send(f'`{userid}` Неверный ID пользователя!', delete_after=5)
            confirmation = BotConfirmation(ctx)
            await confirmation.confirm("Вы уверенны?")

            if confirmation.confirmed:
                await confirmation.update("Подтверждено", hide_author=True)
                await ctx.guild.ban(discord.Object(user.id), reason=reason)
                embed = discord.Embed(title=f'Пользователь {user.name} хак-забанен. ')
                embed.add_field(name="До свидания!", value=":hammer:")
                embed.set_thumbnail(url=user.avatar_url)
                await ctx.send(embed=embed)
            else:
                await confirmation.update("Отменено", hide_author=True)

    @commands.has_permissions(ban_members=True)
    @commands.command(name="unban", description="-moderation:Разбанить пользователя", no_pm=True)
    async def unban(self, ctx, user : discord.User):
        """Unans a user from the server."""
        if ctx.author == user:
            await ctx.send("Вы не забанены.")
        else:
            confirmation = BotConfirmation(ctx)
            await confirmation.confirm("Вы уверенны?")

            if confirmation.confirmed:
                await confirmation.update("Подтверждено", hide_author=True)
                await ctx.guild.unban(discord.Object(user.id))
                embed = discord.Embed(title=f'Пользователь {user.name} разбанен.')
                embed.set_thumbnail(url=user.avatar_url)
                await ctx.send(embed=embed)
            else:
                await confirmation.update("Отменено", hide_author=True)

    @commands.has_permissions(ban_members=True)
    @commands.command(name="softban", description="-moderation:Софт-забанить пользователя", no_pm=True)
    async def softban(self, ctx, user : discord.User, *, reason : str):
        """Softbans a user from the server."""
        if ctx.author == user:
            await ctx.send("Вы не можете софтбанить себя.")
        else:
            confirmation = BotConfirmation(ctx)
            await confirmation.confirm("Вы уверенны?")

            if confirmation.confirmed:
                await confirmation.update("Подтверждено", hide_author=True)
                await ctx.guild.ban(discord.Object(user.id), reason=reason)
                await ctx.guild.unban(discord.Object(user.id))
                embed = discord.Embed(title=f'Пользователь {user.name} был софт-забанен.')
                embed.add_field(name="До свидания!", value=":hammer:")
                embed.set_thumbnail(url=user.avatar_url)
                await ctx.send(embed=embed)
            else:
                await confirmation.update("Отменено", hide_author=True)


    @commands.command(name="", description="-moderation:Информация о бане", no_pm=True)
    async def baninfo(self, ctx, *, name_or_id):
        """ ᗣ Check the reason of a ban """
        ban = await ctx.get_ban(name_or_id)
        e = discord.Embed(color=self.mod_color)
        e.set_author(name=str(ban.user), icon_url=ban.user.avatar_url)
        e.add_field(name='Reason', value=ban.reason or 'None')
        e.set_thumbnail(url=ban.user.avatar_url)
        e.set_footer(text=f'User ID: {ban.user.id}')
        await ctx.send(embed=e)

    @commands.command(name="", description="-moderation:Список всех забаненных пользователей", no_pm=True)
    async def bans(self, ctx):
        """ ᗣ See a list of banned users """
        try:
            bans = await ctx.guild.bans()
        except:
            return await ctx.send("You don't have the perms to see bans. (｡◝‿◜｡)")
        e = discord.Embed(color=self.mod_color)
        e.set_author(name=f'List of Banned Members ({len(bans)}):', icon_url=ctx.guild.icon_url)        
        result = ',\n'.join(["[" + (str(b.user.id) + "] " + str(b.user)) for b in bans])
        if len(result) < 1990:
            total = result
        else:
            total = result[:1990]
            e.set_footer(text=f'Too many bans to show here!')
        e.description = f'```bf\n{total}```'
        await ctx.send(embed=e)

    @commands.has_permissions(kick_members=True)
    @commands.command(name="warn", description="-moderation:Придупредить пользователя", no_pm=True)
    async def warn(self, ctx, user: discord.Member, *, reason: str):
        if not reason:
            await ctx.send("Пожалуйста приведите причину")
            return
        confirmation = BotConfirmation(ctx)
        await confirmation.confirm("Вы уверенны?")

        if confirmation.confirmed:
            await confirmation.update("Подтверждено", hide_author=True)
            reason = ' '.join(reason)
            for current_user in report['users']:
                if current_user['name'] == user.name:
                    current_user['reasons'].append(reason)
                    break
            else:
                report['users'].append({
                    'name': user.name,
                    'reasons': [
                        reason,
                    ]
                })
            with open('reports.json', 'w+') as f:
                json.dump(report, f)

                embed = discord.Embed(
                    title="Придупреждение",
                    description=f"{user.name} был придупреждён за {reason}")
                await ctx.send(embed=embed)
        else:
            await confirmation.update("Отменено", hide_author=True)

    @commands.has_permissions(mute_members=True)
    @commands.command(name="mute", description="-moderation:Замьютить пользователя", no_pm=True)
    async def mute(self, ctx, user : discord.Member, time: int):
        """Prevents a user from speaking for a specified amount of time."""
        if ctx.author == user:
            await ctx.send("Вы не можете замьютить себя.")
        else:
            confirmation = BotConfirmation(ctx)
            await confirmation.confirm("Вы уверенны?")

            if confirmation.confirmed:
                await confirmation.update("Подтверждено", hide_author=True)
                rolem = discord.utils.get(ctx.message.guild.roles, name='Мьют')
                if rolem is None:
                    embed=discord.Embed(title="Мьют", description="Для команды мьюта требуется роль с именем «Мьют».")
                    embed.set_author(name=self.bot.user.name, icon_url=self.bot.user.avatar_url)
                    embed.set_footer(text="Without this role, the command will not work.")
                    await ctx.send(embed=embed)
                elif rolem not in user.roles:
                    embed = discord.Embed(title=f'Пользователь {user.name} был успешно замьючен на {time}с.')
                    embed.add_field(name="Тссс!", value=":zipper_mouth:")
                    embed.set_thumbnail(url=user.avatar_url)
                    await ctx.send(embed=embed)
                    await user.add_roles(rolem)
                    user = await ctx.message.guild.fetch_member(user.id)
                    await sleep(time)
                    if rolem in user.roles:
                        try:
                            await user.remove_roles(rolem)
                            embed = discord.Embed(title=f'Пользователь {user.name} был автоматически размьючен.')
                            embed.add_field(name="Вы снова можете писать!", value=":open_mouth:")
                            embed.set_thumbnail(url=user.avatar_url)
                            await ctx.send(embed=embed)
                        except Exception:
                            print(f'Невозможно размьютить пользователя {user.name}!')
                else:
                    await ctx.send(f'Пользователь {user.mention} уже замьючен.')
            else:
                await confirmation.update("Отменено", hide_author=True)

    @commands.has_permissions(mute_members=True)
    @commands.command(name="unmute", description="-moderation:Размьютить пользователя", no_pm=True)
    async def unmute(self, ctx, user: discord.Member):
        """Unmutes a user."""
        rolem = discord.utils.get(ctx.message.guild.roles, name='Muted')
        if rolem in user.roles:
            confirmation = BotConfirmation(ctx)
            await confirmation.confirm("Вы уверенны?")

            if confirmation.confirmed:
                await confirmation.update("Подтверждено", hide_author=True)
                embed = discord.Embed(title=f'Пользователь {user.name} был вручную разамьючен.')
                embed.add_field(name="Вы снова можете писать!", value=":open_mouth:")
                embed.set_thumbnail(url=user.avatar_url)
                await ctx.send(embed=embed)
                await user.remove_roles(rolem)
            else:
                await confirmation.update("Отменено", hide_author=True)

    @commands.has_permissions(manage_messages=True)
    @commands.command(name="prune", description="-moderation:Очистить чат от указанного количества сообщений")
    async def prune(self, ctx, count: int):
        """Deletes a specified amount of messages. (Max 100)"""
        if count>100:
            count = 100
        await ctx.message.channel.purge(limit=count, bulk=True)

    @commands.has_permissions(manage_messages=True)
    @commands.command(name="clear", description="-moderation:Очистить чат от сообщений бота")
    async def clean(self, ctx):
        """Cleans the chat of the bot's messages."""
        def is_me(m):
            return m.author == self.bot.user
        await ctx.message.channel.purge(limit=100, check=is_me)

    # Voice

    @commands.command(name="voicemute", description="-moderation:Замьютить пользователя в голосовом канале")
    async def voicemute(self, ctx, user : discord.Member):
        confirmation = BotConfirmation(ctx)
        await confirmation.confirm("Вы уверенны?")

        if confirmation.confirmed:
            await confirmation.update("Подтверждено", hide_author=True)
            await user.edit(mute=True)
        else:
            await confirmation.update("Отменено", hide_author=True)

        
    @commands.command(name="voicedeafen", description="-moderation:Зделать человека глухим в голосовом канале")
    async def voicedeafen(self, ctx, user : discord.Member):
        confirmation = BotConfirmation(ctx)
        await confirmation.confirm("Вы уверенны?")

        if confirmation.confirmed:
            await confirmation.update("Подтверждено", hide_author=True)
            await user.edit(deafen=True)
        else:
            await confirmation.update("Отменено", hide_author=True)

    @commands.command(name="voiceunmute", description="-moderation:Разамьютить пользователя в голосовом канале")
    async def voiceunmute(self, ctx, user : discord.Member):
        confirmation = BotConfirmation(ctx)
        await confirmation.confirm("Вы уверенны?")

        if confirmation.confirmed:
            await confirmation.update("Подтверждено", hide_author=True)
            await user.edit(mute=False)
        else:
            await confirmation.update("Отменено", hide_author=True)

    @commands.command(name="voiceundeafen", description="-moderation:Зделать человека слышащим в голосовом канале")
    async def voiceundeafen(self, ctx, user : discord.Member):
        confirmation = BotConfirmation(ctx)
        await confirmation.confirm("Вы уверенны?")

        if confirmation.confirmed:
            await confirmation.update("Подтверждено", hide_author=True)
            await user.edit(deafen=False)
        else:
            await confirmation.update("Отменено", hide_author=True)

def setup(bot):
    bot.add_cog(Moderation(bot))