import time
import discord
import datetime

from discord.ext import commands

start_time = time.time()

class Information(commands.Cog):
    """Retrieve information about various items."""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="userinfo", description="-info:Показать информацию о указанном пользователе")
    async def userinfo(self, ctx, user: discord.Member = None):
        if user is None:
            user = ctx.message.author
        if user.activity is not None:
            game = user.activity.name
        else:
            game = None
        voice_state = None if not user.voice else user.voice.channel
        embed = discord.Embed(timestamp=ctx.message.created_at)
        embed_values = {
            "ID": user.id,
            "Никнейм": str(user.nick).replace('None','Нет'),
            "Статус": str(user.status).replace('offline','Оффлайн') or game.replace('online','Онлайн'),
            "С телефона": str(user.is_on_mobile()).replace('False','Нет') or game.replace('True','Да'),
            "В голосовом": str(voice_state).replace('None','Нет') or game.replace('True','Да'),
            "Играет": str(game).replace('None','Нет') or game.replace('True','Да'),
            "Наивысшая роль": user.top_role.name,
            "Создан": user.created_at.__format__('%A, %d. %B %Y @ %H:%M:%S'),
            "Присоеденился": user.joined_at.__format__('%A, %d. %B %Y @ %H:%M:%S')
        }
        for n, v in embed_values.items():
            embed.add_field(name=n, value=v, inline=True)
        embed.set_thumbnail(url=user.avatar_url)
        embed.set_author(name=user.name, icon_url=user.avatar_url)
        embed.set_footer(text=self.bot.user.name, icon_url=self.bot.user.avatar_url)
        await ctx.send(embed=embed)

    @commands.command(name="serverinfo", description="-info:Показать информацию о сервере")
    async def serverinfo(self, ctx):
        role_count = len(ctx.guild.roles)
        emoji_count = len(ctx.guild.emojis)
        channel_count = len([x for x in ctx.guild.channels if isinstance(x, discord.channel.TextChannel)])
        embed = discord.Embed(timestamp=ctx.message.created_at)
        embed_values = {
            "Название (ID)": (f"{ctx.guild.name} ({ctx.guild.id})", False),
            "Владелец": (ctx.guild.owner, False),
            "Участников": (ctx.guild.member_count, True),
            "Текстовых каналов": (str(channel_count), True),
            "Регион": (ctx.guild.region, True),
            "Уровень верификации": (str(ctx.guild.verification_level), True),
            "Наивысшая роль": (ctx.guild.roles[-1], True),
            "Кол.во ролей": (str(role_count), True),
            "Кол.во эмодзи": (str(emoji_count), True),
            "Создан": (ctx.guild.created_at.__format__('%A, %d. %B %Y @ %H:%M:%S'), True)
        }
        for n, v in embed_values.items():
            embed.add_field(name=n, value=v[0], inline=v[1])
        embed.set_thumbnail(url=ctx.guild.icon_url)
        embed.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)
        embed.set_footer(text=self.bot.user.name, icon_url=self.bot.user.avatar_url)
        await ctx.send(embed=embed)

    @commands.command(name="invite", description="-info:Пригласить бота на свой сервер")
    async def invite(self, ctx):
        """Print out a clickable link to invite yin."""
        embed = discord.Embed(title="Пригласить бота на свой сервер", description="Вы можете пригласить бота на свой сервер по ссылке\n[тык](https://discord.com/api/oauth2/authorize?client_id=813690010410287126&permissions=8&scope=bot)")
        await ctx.send(embed=embed)

    @commands.command(name="uptime", description="-info:Аптайм бота")
    async def uptime(self, ctx):
        """Print out uptime of bot."""
        current_time = time.time()
        difference = int(round(current_time - start_time))
        text = str(datetime.timedelta(seconds=difference))
        embed = discord.Embed()
        embed.add_field(name="Аптайм", value=text)
        try:
            await ctx.send(embed=embed)
        except discord.HTTPException:
            await ctx.send("Текущий аптайм: " + text)

    @commands.command(name="stats", description="-info:Статистика бота")
    async def stats(self, ctx):
        """Print out stats embed."""
        current_time = time.time()
        difference = int(round(current_time - start_time))
        text = str(datetime.timedelta(seconds=difference))
        total_servers = len(self.bot.guilds)
        total_users = len(self.bot.users)
        local_embed = discord.Embed(
            title=f'Статистика',
            description=f'Всего серверов: {total_servers}\n'
                        f'Всего пользователей: {total_users}\n'
                        f'Аптайм: {text}\n'
        )
        await ctx.send(embed=local_embed)

def setup(bot):
    bot.add_cog(Information(bot))