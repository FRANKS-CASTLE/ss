from discord.ext import commands

class Admin(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='load', description="Загрузить ког")
    @commands.is_owner()
    async def cogload(self, ctx, *, cog: str):
        try:
            self.bot.load_extension(cog)
        except Exception as e:
            await ctx.send(f'**ОШИБКА:** {type(e).__name__} - {e}')
        else:
            await ctx.send('**УСПЕХ**')

    @commands.command(name='unload', description="Отгрузить ког")
    @commands.is_owner()
    async def cogunload(self, ctx, *, cog: str):
        try:
            self.bot.unload_extension(cog)
        except Exception as e:
            await ctx.send(f'**ОШИБКА:** {type(e).__name__} - {e}')
        else:
            await ctx.send('**УСПЕХ**')

    @commands.command(name='reload', description="Перезагрузить ког")
    @commands.is_owner()
    async def cogreload(self, ctx, *, cog: str):
        try:
            self.bot.unload_extension(cog)
            self.bot.load_extension(cog)
        except Exception as e:
            await ctx.send(f'**ОШИБКА:** {type(e).__name__} - {e}')
        else:
            await ctx.send('**УСПЕХ**')


def setup(bot):
    bot.add_cog(Admin(bot))