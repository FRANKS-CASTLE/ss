import random
import discord
import datetime

from disputils import BotEmbedPaginator
from discord.ext import commands

class Informational(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help", description="-help:Вывести это сообщение")
    async def help(self, ctx):
        
        help_embed = discord.Embed(title='Помощь', description='Название говорит само за себя', timestamp=datetime.datetime.today())
        moderation_embed = discord.Embed(title='Модерация', description='Для модераторов - самое то!', timestamp=datetime.datetime.today())
        info_embed = discord.Embed(title='Инфо', description='Важнейшая информация пентагона', timestamp=datetime.datetime.today())
        music_embed = discord.Embed(title='Музыка', description='Команды для меломанов', timestamp=datetime.datetime.today())
        fun_embed = discord.Embed(title='Весёлости', description='Всякие прикольные штучки', timestamp=datetime.datetime.today())
        util_embed = discord.Embed(title='Утилиты', description='Финтифлюшки', timestamp=datetime.datetime.today())

        for command in self.bot.commands:
            if "-help:" in command.description:
                help_embed.add_field(name=command.name, value=command.description.replace("-help:",""), inline=True)
            if "-moderation:" in command.description:
                moderation_embed.add_field(name=command.name, value=command.description.replace("-moderation:",""), inline=True)
            if "-info:" in command.description:
                info_embed.add_field(name=command.name, value=command.description.replace("-info:",""), inline=True)
            if "-music:" in command.description:
                music_embed.add_field(name=command.name, value=command.description.replace("-music:",""), inline=True)
            if "-fun:" in command.description:
                fun_embed.add_field(name=command.name, value=command.description.replace("-fun:",""), inline=True)
            if "-utils:" in command.description:
                util_embed.add_field(name=command.name, value=command.description.replace("-utils:",""), inline=True)
                
        embeds = [help_embed, moderation_embed, info_embed, music_embed, fun_embed, util_embed]
        paginator = BotEmbedPaginator(ctx, embeds)
        await paginator.run()

def setup(bot):
    bot.add_cog(Informational(bot))