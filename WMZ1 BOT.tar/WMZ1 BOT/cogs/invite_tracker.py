import discord
import DiscordUtils
from discord.ext import commands

class InviteTracker(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.tracker = DiscordUtils.InviteTracker(self.bot)

    @commands.Cog.listener()
    async def on_ready():
        await self.tracker.cache_invites()

    @commands.Cog.listener()
    async def on_invite_create(invite):
        await self.tracker.update_invite_cache(invite)

    @commands.Cog.listener()
    async def on_guild_join(guild):
        await self.tracker.update_guild_cache(guild)

    @commands.Cog.listener()
    async def on_invite_delete(invite):
        await self.tracker.remove_invite_cache(invite)

    @commands.Cog.listener()
    async def on_guild_remove(guild):
        await self.tracker.remove_guild_cache(guild)

    @commands.Cog.listener()
    async def on_member_join(member):
        inviter = await self.tracker.fetch_inviter(member)
        
def setup(bot):
    bot.add_cog(InviteTracker(bot))