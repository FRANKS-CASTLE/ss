import time
import random
import discord
import datetime

from discord.ext import commands

class Fun(commands.Cog):
    """Miscellaneous commands."""
    def __init__(self,bot):
        self.bot = bot

    @commands.command(name="say", description="-fun:Сказать что-то от имени бота")
    async def say(self, ctx, *, message):
        if '@everyone' in message:
            await сtx.send('Хорошая попытка.')
            await ctx.message.delete()
            return
        elif '@here' in message:
            await сtx.send('Хорошая попытка.')
            await ctx.message.delete()
            return
        else:
            await ctx.send(message)
            await ctx.message.delete()

    @commands.command(name="emb", description="-fun:Отправить эмбед")
    async def emb(self, ctx, *, cntnt):
        try:
            await ctx.message.delete()
        except:
            pass
        embed = discord.Embed(title=self.bot.user.name, timestamp=datetime.datetime.today())
        embed.set_author(name=ctx.author.display_name, url=f"https://discord.com/channels/@me/{ctx.message.author.id}/")
        embed.set_footer(text='© i0x')
        embed.add_field(name='᠌Сообщение', value=f"```{cntnt}```")
        await ctx.send(embed=embed)
        
        
    @commands.command(name="embmin", description="-fun:Отправить эмбед (минималистический)")
    async def embmin(self, ctx, *, cntnt):
        try:
            await ctx.message.delete()
        except:
            pass
        embed = discord.Embed(title=self.bot.user.name, description=f'```{cntnt}```', timestamp=datetime.datetime.today())
        await ctx.send(embed=embed)
        
    @commands.command(name="embmin2", description="-fun:Отправить эмбед (минималистический v2)")
    async def embmin2(self, ctx, *, cntnt):
        try:
            await ctx.message.delete()
        except:
            pass
        embed = discord.Embed(description=f'```{cntnt}```')
        await ctx.send(embed=embed)

    @commands.command(name="penis", description="-fun:Размер пениса")
    async def penis(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass
        penis = '8'
        size = random.randint(1, 25)
        for i in range(size):
            penis += '='
        penis += 'D'
        await ctx.channel.send(f"\nРазмер твоего пениса -> {size}\n{penis}")

    @commands.command(name="table", description="-fun:Швырнуть стол в кого-то")
    async def throw(self, ctx, user_throw: discord.Member = None):
        try:
            await ctx.message.delete()
        except:
            pass
        throw = "(╯°□°）╯︵ ┻━┻"
        if not user_throw:
            throw_embed = discord.Embed(description=f"{ctx.author.name} швырнул(а) стол\n{throw}")
            throw_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=throw_embed)
        else:
            throw_embed = discord.Embed(description=f"{ctx.author.name} швырнул(а) стол в {user_throw.name}\n{throw}")
            throw_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=throw_embed)

    @commands.command(name="pat", description="-fun:Погладить кого-то")
    async def pat(self, ctx, user_pat: discord.Member = None):
        try:
            await ctx.message.delete()
        except:
            pass
        pat_gif = ['https://media.giphy.com/media/N0CIxcyPLputW/giphy.gif', 'https://media.giphy.com/media/ye7OTQgwmVuVy/giphy.gif', 'https://media.giphy.com/media/5tmRHwTlHAA9WkVxTU/giphy.gif', 'https://media.giphy.com/media/ARSp9T7wwxNcs/giphy.gif', 'https://media.giphy.com/media/Z7x24IHBcmV7W/giphy.gif', 'https://media.giphy.com/media/e7xQm1dtF9Zni/giphy.gif', 'https://media.giphy.com/media/l2Je0SJkEt7MhgyM8/giphy.gif',
                   'https://media.giphy.com/media/L2z7dnOduqEow/giphy.gif', 'https://media.giphy.com/media/osYdfUptPqV0s/giphy.gif', 'https://media.giphy.com/media/4HP0ddZnNVvKU/giphy.gif', 'https://media.giphy.com/media/JUuk5SRw5ZmRG/giphy.gif', 'https://images-ext-1.discordapp.net/external/8ENOBBPn_grEMi4-RtUYmEsoEiqF3dORHsguNSVFitY/https/media.tenor.co/images/e7db87c553dd0383273ace277c27d31b/tenor.gif']
        if not user_pat:
            pat_embed = discord.Embed(description=f"{ctx.author.name} погладил(а) всех", color=3553598)
            pat_embed.set_image(url=random.choice(pat_gif))
            pat_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=pat_embed)
        else:
            pat_embed = discord.Embed(description=f"{ctx.author.name} погладил(а) {user_pat.name}", color=3553598)
            pat_embed.set_image(url=random.choice(pat_gif))
            pat_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=pat_embed)


    @commands.command(name="hug", description="-fun:Обнять кого-то")
    async def hug(self, ctx, user_hug: discord.Member = None):
        try:
            await ctx.message.delete()
        except:
            pass
        hug_gif = ['https://i.pinimg.com/originals/24/00/ee/2400eec8e83624dc8114a74261a145fe.gif', 'https://media1.tenor.com/images/234d471b1068bc25d435c607224454c9/tenor.gif?itemid=3532081',
                   'https://i.gifer.com/NOkF.gif', 'https://pa1.narvii.com/6569/56b815b794d667d5039dcaf6af3a215cad5cc6a2_hq.gif', 'https://i.gifer.com/AmeN.gif']
        if not user_hug:
            hug_embed = discord.Embed(description=f"{ctx.author.name} обнял(а) всех", color=3553598)
            hug_embed.set_image(url=random.choice(hug_gif))
            hug_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=hug_embed)
        else:
            hug_embed = discord.Embed(description=f"{ctx.author.name} обнял(а) {user_hug.name}", color=3553598)
            hug_embed.set_image(url=random.choice(hug_gif))
            hug_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=hug_embed)


    @commands.command(name="lick", description="-fun:Лизнуть кого-то")
    async def lick(self, ctx, user_lick: discord.Member = None):
        try:
            await ctx.message.delete()
        except:
            pass
        lick_gif = ['https://4.bp.blogspot.com/-SfFnJBLVyWs/WBbW0ZEIRSI/AAAAAAAApPg/o0jNtlCxuF85T_FzVPoxkliJ3z3P5bNWQCPcB/s1600/Omake%2BGif%2BAnime%2B-%2BLong%2BRiders%2521%2B-%2BEpisode%2B3%2B-%2BIndy%2BDog%2BLicks%2BAmi.gif',
                    'https://pa1.narvii.com/7101/224b3367affb1ed0dcbead814f3f4ebf89b35a54r1-542-307_hq.gif', 'https://i.gyazo.com/c45d55e29820af5e8dc1b893507f3365.gif']
        if not user_lick:
            lick_embed = discord.Embed(description=f"{ctx.author.name} лизнул(а) всех", color=3553598)
            lick_embed.set_image(url=random.choice(lick_gif))
            lick_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=lick_embed)
        else:
            lick_embed = discord.Embed(description=f"{ctx.author.name} лизнул(а) {user_lick.name}", color=3553598)
            lick_embed.set_image(url=random.choice(lick_gif))
            lick_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=lick_embed)


    @commands.command(name="kiss", description="-fun:Поцеловать кого-то")
    async def kiss(self, ctx, user_kiss: discord.Member = None):
        try:
            await ctx.message.delete()
        except:
            pass
        kiss_gif = ['https://data.whicdn.com/images/294084710/original.gif',
                    'https://pa1.narvii.com/6703/56deba239ddba81953c40a8c31dcb6c82cada176_hq.gif']
        if not user_kiss:
            kiss_embed = discord.Embed(description=f"{ctx.author.name} поцеловал(а) всех", color=3553598)
            kiss_embed.set_image(url=random.choice(kiss_gif))
            kiss_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=kiss_embed)
        else:
            kiss_embed = discord.Embed(description=f"{ctx.author.name} поцеловал(а) {user_kiss.name}", color=3553598)
            kiss_embed.set_image(url=random.choice(kiss_gif))
            kiss_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=kiss_embed)


    @commands.command(name="bite", description="-fun:Укусить кого-то")
    async def bite(self, ctx, user_bite: discord.Member = None):
        try:
            await ctx.message.delete()
        except:
            pass
        bite_gif = ['https://i.pinimg.com/originals/c0/b4/a9/c0b4a94993a08d1df826e27e55dd2fb0.gif', 'https://data.whicdn.com/images/209439176/original.gif',
                    'https://pa1.narvii.com/6544/513943fd84bfe1f3808c667dc9a2334b29f66c79_hq.gif', 'https://media1.tenor.com/images/6b42070f19e228d7a4ed76d4b35672cd/tenor.gif?itemid=9051585']
        if not user_bite:
            bite_embed = discord.Embed(description=f"{ctx.author.name} сделал(а) кусь всем", color=3553598)
            bite_embed.set_image(url=random.choice(bite_gif))
            bite_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=bite_embed)
        else:
            bite_embed = discord.Embed(description=f"{ctx.author.name} сделал(а) кусь {user_bite.name}", color=3553598)
            bite_embed.set_image(url=random.choice(bite_gif))
            bite_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=bite_embed)


    @commands.command(name="kill", description="-fun:Убить кого-то")
    async def kill(self, ctx, user_kill: discord.Member = None):
        try:
            await ctx.message.delete()
        except:
            pass
        kill_gif = ['https://i.pinimg.com/originals/19/88/c8/1988c8d65590df4df62894495e44343c.gif', 'https://24.media.tumblr.com/68472fad036c03520ee5e5ef6825c188/tumblr_mwobunzhg01rcj8eco1_500.gif',
                    'https://38.media.tumblr.com/d0bb21ba12720d57a19b127ea2c84856/tumblr_n90q272eto1sijhkdo1_500.gif', 'https://i.gifer.com/FRSe.gif', 'https://steamuserimages-a.akamaihd.net/ugc/88220071323623078/95EA1F93CEE7FDF50CA78D5EEFA076AA29F3C0D2/']
        if not user_kill:
            kill_embed = discord.Embed(description=f"{ctx.author.name} убил(а) всех", color=3553598)
            kill_embed.set_image(url=random.choice(kill_gif))
            kill_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=kill_embed)
        else:
            kill_embed = discord.Embed(description=f"{ctx.author.name} убил(а) {user_kill.name}", color=3553598)
            kill_embed.set_image(url=random.choice(kill_gif))
            kill_embed.set_footer(
                text='© i0x', icon_url=ctx.author.avatar_url)
            await ctx.channel.send(embed=kill_embed)

def setup(bot):
    bot.add_cog(Fun(bot))