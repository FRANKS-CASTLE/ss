from functions import *

import os
import sys
import glob
import time
import uuid
import discord
import hashlib
import requests
import traceback

import DiscordUtils

from pathlib import Path

from os import listdir
from os.path import isfile, join
from discord.ext import commands


class Client:
    environment_variables = {'author': 'WMZ1', 'ver': 6.0, 'site': 'https://sevenfoureight.ml/'}

    class Settings:
        description      = ''
        client_token     = "ODEzNjkwMDEwNDEwMjg3MTI2.YDS94A.N6Olu0KF4-9QKWhGx7g3bTZdOFA"
        command_prefix   = '-'
        self_bot         = False
        bot              = True
        case_insensitive = True
        cogs_dir         = 'cogs'
        cogs             = [p.stem for p in Path(".").glob("cogs/*.py")]

_ = Client.Settings

bot = commands.AutoShardedBot(description = _.description,
                command_prefix = _.command_prefix,
                self_bot = _.self_bot,
                case_insensitive = _.case_insensitive)
                
bot.remove_command('help')

if __name__ == "__main__":
    for cog in _.cogs:
        try:
            bot.load_extension(_.cogs_dir + '.' + cog)
        except Exception as e:
            print(f'Не удалось загрузить расширение {cog}.')
            traceback.print_exc()

bot.run(_.client_token, bot=_.bot)
